<?php

require_once( 'settings.inc.php' );
require_once( 'connect.inc.php' );
require_once( 'dbutils.inc.php' );
require_once( 'utilities.inc.php' );

echo '<iframe width="640" height="360" src="https://www.youtube.com/embed/_6WtIxh6oj8"></iframe>';

?>
